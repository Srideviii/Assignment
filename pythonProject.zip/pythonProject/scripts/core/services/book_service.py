from fastapi import APIRouter

from schemas.models import Email
from scripts.core.handlers.book_handler import *
from scripts.core.handlers.email_handler import send_email

app = APIRouter()


@app.get("/")
def fun():
    return get_book()


@app.post("/books/book_id")
def fun(book: Book):
    return create_book(book)


@app.put("/book/{book_id}")
def upd(book_id: int, book: Book):
    return update_book(book_id, book)


@app.delete("/books/{book_id}")
def de(book_id: int):
    return delete_book(book_id)


@app.post("/send_email")
def fun(email: Email):
    return send_email(email)


@app.get("/Total_price")
def pipe():
    return pipeline_agg()
