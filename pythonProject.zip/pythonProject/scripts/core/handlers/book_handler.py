from schemas.models import Book
from scripts.core.db.mongodb import book_1


def get_book():
    return {"hi"}


def create_book(book: Book):
    book_1.insert_one(book.dict())
    return {"ok"}


def update_book(book_id: int, book: Book):
    book_1.update_one({'book_id': book_id}, {'$set': book.dict()})
    return {"message": "Book updated successfully"}


def delete_book(book_id: int):
    book_1.delete_one({'book_id': book_id})
    return {"message": "Book deleted successfully"}


def pipeline_agg():
    pipeline = [
    {
        '$addFields': {
            'Total_price': {
                '$multiply': [
                    '$quanity', '$cost'
                ]
            }
        }
    }, {
        '$group': {
            '_id': None,
            'Sum_of_all_price': {
                '$sum': '$Total_price'
            }
        }
    }, {
        '$project': {
            '_id': 0
        }
    }
]
    data = book_1.aggregate(pipeline)
    data = list(data)
    print(data)
    return {"Total_price": data[0]['Sum_of_all_price']}
